import React, { Component } from 'react'
import { View, Text, Button } from 'react-native'

export default class Pagina2 extends Component{
    
    render() {
        return(
            <View>
                <Text> pagina 2 test 1 </Text>
               
            </View>
        )
    }
}