import React, { Component } from 'react'
import { View, Text, Button } from 'react-native'

export default class Pagina3 extends Component{
    
    render() {
        return(
            <View>
                <Text> pagina 3</Text>
               
            </View>
        )
    }
}