import React, { Component } from 'react'
import { View, Text, Button } from 'react-native'

export default class Main extends Component{
    render() {
        return(
            <View>
                <Text> pagina Main</Text>
                <Button
        title="home"
        onPress={() => this.props.navigation.openDrawer()}
      />
            </View>
        )
    }
}
