import React, { Component } from 'react'
import Routes from './routes/routes'
 
const App = () => <Routes/>;

export default App;
